define(function(require) {
    'use strict';
    require('components/registration_count/directives/elem_data');
});