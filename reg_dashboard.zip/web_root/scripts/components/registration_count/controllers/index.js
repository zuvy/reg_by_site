'use strict';
define(function(require) {
    // Require all controllers at this level
    require('components/registration_count/controllers/elemctrl');
    require('components/registration_count/controllers/settingsctrl');
    require('components/registration_count/controllers/testctrl');
});