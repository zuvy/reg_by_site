'use strict';
define(function(require) {
    var angular = require('angular');
    
    // Define the module - this is where we add it to AngularJS module list
    return angular.module('regAppModule', []);
});