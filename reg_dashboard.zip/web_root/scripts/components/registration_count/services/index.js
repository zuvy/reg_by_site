'use strict';
define(function(require) {
    // Require all services at this level
    require('components/registration_count/services/elem_data');
});